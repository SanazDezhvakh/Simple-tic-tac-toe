#include <iostream>
using namespace std;

char board[3][3] = {{'1','2','3'}, {'4','5','6'}, {'7','8','9'}};
int turn = 0;

void showBoard() {
    for (int i = 0; i < 3; i++) {
        cout << board[i][0] << " " << board[i][1] << " " << board[i][2] << endl;
    }
}

void playerMove(char player) {
    int choice;
    cout << "Player " << player << ", choose a number (1-9): ";
    cin >> choice;
    
    int row = (choice - 1) / 3;
    int col = (choice - 1) % 3;
    
    if (board[row][col] != 'X' && board[row][col] != 'O') {
        board[row][col] = player;
    } else {
        cout << "Cell already taken! Try again.\n";
        playerMove(player);
    }
}

int main() {
    char player;
    while (turn < 9) {
        showBoard();
        player = (turn % 2 == 0) ? 'X' : 'O';
        playerMove(player);
        turn++;
    }
    showBoard();
    cout << "Game over!\n";
    return 0;
}
